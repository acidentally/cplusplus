#include <bits/stdc++.h>
using namespace std;

int main() {
	string s; getline(cin, s); 
	string temp;
	for(int i = 0; i < s.length(); i++) {
		if(s[i] != ' ') {
			temp += s[i];
		}
		
		if(s[i] == ' ' || i == s.length() - 1) {
			cout << temp << endl;
			temp = "";
		}
	}
}