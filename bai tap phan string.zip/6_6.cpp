#include <bits/stdc++.h>
using namespace std;

int main() {
	string s; cin >> s;
	int thuong = 0, hoa = 0;
	for(int i = 0; i < s.size(); i++) {
		if(s[i] >= 97) {
			thuong += 1;
		}
		if(s[i] <= 90) {
			hoa += 1;
		}
	}
	cout << thuong << ' ' << hoa;
}