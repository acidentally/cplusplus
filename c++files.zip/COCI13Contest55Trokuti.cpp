//https://dmoj.ca/problem/coci13c5p5?fbclid=IwAR0aQpzI8DDU796BEIBsBtTI7M3Hepse57hHhJYCEGEU0HanyG-NZvaiFbw
#include <bits/stdc++.h>
using namespace std;
__int64 const p = (int)10e9 + 7;



int main() {

	ios_base:: sync_with_stdio(0); cin.tie(0); cout.tie(0);

	__int64 temporary;


	int N; cin >> N;
	__int32 temp2;
	double A, B, C;
	bool tructung = false, truchoanh = false;
	map<double, set<double>> heso;
	set<double> ngang, doc;
	int ngn, docc;

	for(int i = 0; i < N; i++) {
		cin >> A >> B >> C;
		if(A == 0 && C == 0) truchoanh = true;
		else if(B == 0 && C == 0) tructung = true;
		else if(A == 0 && B != 0) ngang.insert(C/B);
		else if(B == 0 && A != 0) doc.insert(C/A);

		else if(A && B) {
			heso[B/A].insert(C/A);
		}
	}
	if(truchoanh) ngn = ngang.size() + 1;
	if(tructung) docc = doc.size() + 1;
	temporary = ngn + docc;
	for(auto it = heso.begin(); it != heso.end(); it++) {
		set<double> st = it -> second;
		temporary += st.size();
	}
	
	temporary = (temporary * (temporary - 1)) / 2 % p;

	for(auto it = heso.begin(); it != heso.end(); it++) {
		set<double> st = it -> second;
		temporary = (temporary - ((st.size() % p) * ((st.size()-1) % p) / 2)) % p;
		
	}
	if(temporary < 0) temporary = p + temporary;
	temporary = temporary - ngn * (ngn - 1) / 2 - (docc - 1) * docc / 2;
	cout << temporary;

}