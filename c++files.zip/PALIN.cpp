#include <bits/stdc++.h>
using namespace std;

int main() {
	string a;
	cin >> a;
	int s = a.length()/2;
	int lover = a - 2*s;
	int mid = 
	for(int i = a.length(); i > s + lover; i--) {
		if(s[i+1] >)
	}
}


12873561 26734576

s = 8, lover = 0; mid = 8.5
s + vitri + lover
s - vitri + 1