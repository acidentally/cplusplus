#include <bits/stdc++.h>
using namespace std;

void primes(int a, int b) {
	vector<bool> isPrime(b - a + 1, true);
	for(int i = 2; i * i <= b; i++) {
		for(int j = max(i * i, (a + i - 1) / i * i); j <= b; j += i) {
			isPrime[j - a] = false;
		}
	}
	if(a == 1) {
		isPrime[0] = false;
	}

	for(int i = a; i <= b; i++) {
		if(isPrime[i - a]) {
			cout << i << '\n';
		}
	}
}


int main() {
	int t; cin >> t;
	int m[t + 1], n[t + 1];
	for(int i = 1; i <= t; i++) {
		cin >> m[i] >> n[i];
		primes(m[i], n[i]);
		cout << '\n';
	}
	return 0;
}


