#include <bits/stdc++.h>
using namespace std;
#define int long long
signed main() {
	int n; cin >> n; cout << (int)sqrt(n);
}