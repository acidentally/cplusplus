#include <bits/stdc++.h>
using namespace std;

int n;

void daynhiphan(int i) {
	if(i == 1) {
		cout << 0 << endl << 1;
	}
	else {
		
	}
}

int main() {
	ios_base:: sync_with_stdio(0); cin.tie(0); cout.tie(0);
	cin >> n;
	daynhiphan(5);
}