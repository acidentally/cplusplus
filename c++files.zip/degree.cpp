#include <bits/stdc++.h>
using namespace std;

void eratos() {
	
}

degree(int a, int b, int bac, int coso) {
	if(coso == 2 || coso == 4) {coso = 8;}
	if(coso == 3) {coso = 9;}
}

int main() {
	int X, Y, K, B;
	cin >> X >> Y >> K >> B;

}


1 2 3 4 5 6 7 8 9 10 11 12 13 14
i