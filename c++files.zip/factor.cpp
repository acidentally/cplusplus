#include <bits/stdc++.h>
using namespace std;

string fac(string a) {
	rhadh
}

int main() {
	int t; cin >> t;
	string n;
	while(t--) {
		cin >> n;
		cout << fac(n) << '\n';
	}
	return 0;
}

1