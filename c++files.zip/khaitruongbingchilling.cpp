#include <bits/stdc++.h>
using namespace std;

int main() {
	int t; cin >> t;
	int n, k;
	int h[n + 1];
	while(t--) {
		cin >> n >> k;
		for(int i = 1; i <=)
	}
}