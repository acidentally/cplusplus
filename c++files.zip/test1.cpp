#include <bits/stdc++.h>
using namespace std;
int tonum(string a) {
	int ans = 0;
	for(int i = 0; i < a.size(); i++) {
		ans = ans * 10 + a[i] - '0';
	} return ans;
}
int main() {
	int a = tonum("0873617826378126");
	cout << a;
}