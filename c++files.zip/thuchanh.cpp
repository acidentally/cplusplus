//nhập một số hệ 10, in ra số hệ 2
#include <bits/stdc++.h>
using namespace std;

int main() {
	ios_base:: sync_with_stdio(0); cin.tie(0); cout.tie(0);
	unsigned long long N; cin >> N;
	unsigned long long res = 0, cnt = 1;
	while(N) {
		res += (N % 2) * cnt;
		cnt *= 10;
		N /= 2;
	}
	cout << res;
}